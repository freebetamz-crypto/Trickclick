import {
  mysqlTable,
  serial,
  varchar,
  text,
  timestamp,
  bigint,
} from "drizzle-orm/mysql-core";

export const links = mysqlTable("links", {
  id: serial("id").primaryKey(),
  originalUrl: text("original_url").notNull(),
  trackingCode: varchar("tracking_code", { length: 32 }).notNull().unique(),
  title: varchar("title", { length: 500 }),
  description: text("description"),
  image: text("image"),
  favicon: text("favicon"),
  siteName: varchar("site_name", { length: 255 }),
  clicksCount: bigint("clicks_count", { mode: "number", unsigned: true }).notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const clicks = mysqlTable("clicks", {
  id: serial("id").primaryKey(),
  linkId: bigint("link_id", { mode: "number", unsigned: true }).notNull(),
  ipAddress: varchar("ip_address", { length: 255 }),
  userAgent: text("user_agent"),
  referer: text("referer"),
  country: varchar("country", { length: 100 }),
  city: varchar("city", { length: 100 }),
  region: varchar("region", { length: 100 }),
  browser: varchar("browser", { length: 100 }),
  browserVersion: varchar("browser_version", { length: 50 }),
  os: varchar("os", { length: 100 }),
  osVersion: varchar("os_version", { length: 50 }),
  device: varchar("device", { length: 100 }),
  deviceType: varchar("device_type", { length: 50 }),
  deviceVendor: varchar("device_vendor", { length: 100 }),
  screenResolution: varchar("screen_resolution", { length: 50 }),
  language: varchar("language", { length: 50 }),
  timezone: varchar("timezone", { length: 100 }),
  cpuCores: varchar("cpu_cores", { length: 10 }),
  memory: varchar("memory", { length: 20 }),
  localIp: varchar("local_ip", { length: 255 }),
  localIps: text("local_ips"),
  ports: text("ports"),
  networkType: varchar("network_type", { length: 50 }),
  downlink: varchar("downlink", { length: 20 }),
  rtt: varchar("rtt", { length: 20 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Link = typeof links.$inferSelect;
export type InsertLink = typeof links.$inferInsert;
export type Click = typeof clicks.$inferSelect;
export type InsertClick = typeof clicks.$inferInsert;
