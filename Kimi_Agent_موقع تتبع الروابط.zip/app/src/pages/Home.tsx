import { useState } from "react";
import { Link } from "react-router";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Link2,
  Copy,
  Check,
  ExternalLink,
  BarChart3,
  Globe,
  FileText,
  Clock,
  MousePointerClick,
  QrCode,
  Smartphone,
  Shield,
  Zap,
  Eye,
} from "lucide-react";

export default function Home() {
  const [url, setUrl] = useState("");
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [showPreview, setShowPreview] = useState(false);
  const [selectedLink, setSelectedLink] = useState<any>(null);
  const [showQR, setShowQR] = useState<string | null>(null);

  const utils = trpc.useUtils();
  const { data: links, isLoading } = trpc.link.list.useQuery();
  const createLink = trpc.link.create.useMutation({
    onSuccess: () => {
      utils.link.list.invalidate();
      setUrl("");
    },
  });

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim()) return;
    let targetUrl = url.trim();
    if (!/^https?:\/\//i.test(targetUrl)) {
      targetUrl = "https://" + targetUrl;
    }
    createLink.mutate({ url: targetUrl });
  };

  const copyToClipboard = (text: string, code: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopiedCode(code);
      setTimeout(() => setCopiedCode(null), 2000);
    });
  };

  const getShortUrl = (code: string) => {
    const baseUrl = window.location.origin;
    return `${baseUrl}/s/${code}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-white">
      {/* Header */}
      <header className="border-b border-white/5 bg-white/[0.02] backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-lg shadow-emerald-500/20">
              <Link2 className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold bg-gradient-to-r from-white to-slate-400 bg-clip-text text-transparent">
                LinkTrack Pro
              </h1>
              <p className="text-xs text-slate-500">Smart URL Shortener &amp; Tracker</p>
            </div>
          </div>
          <div className="flex items-center gap-4 text-sm text-slate-400">
            <div className="hidden sm:flex items-center gap-2">
              <Shield className="w-4 h-4 text-emerald-400" />
              <span>{links?.length || 0} Links</span>
            </div>
            <div className="hidden sm:flex items-center gap-2">
              <MousePointerClick className="w-4 h-4 text-blue-400" />
              <span>{links?.reduce((acc, l) => acc + l.clicksCount, 0) || 0} Clicks</span>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-white via-slate-200 to-slate-400 bg-clip-text text-transparent">
            Shorten &amp; Track Links
          </h2>
          <p className="text-slate-400 max-w-2xl mx-auto text-lg">
            Create short links with advanced tracking. Get real-time analytics on clicks, devices, locations, and more.
          </p>
        </div>

        {/* Create Link Form */}
        <div className="max-w-2xl mx-auto mb-16">
          <Card className="bg-white/5 border-white/10 backdrop-blur-sm">
            <CardContent className="pt-6">
              <form onSubmit={handleCreate} className="space-y-4">
                <div className="flex gap-3">
                  <div className="relative flex-1">
                    <Globe className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                    <Input
                      type="url"
                      placeholder="Paste your long URL here..."
                      value={url}
                      onChange={(e) => setUrl(e.target.value)}
                      className="pl-10 h-12 bg-white/5 border-white/10 text-white placeholder:text-slate-500 focus:border-emerald-500/50 focus:ring-emerald-500/20"
                      required
                    />
                  </div>
                  <Button
                    type="submit"
                    disabled={createLink.isPending}
                    className="h-12 px-6 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-semibold shadow-lg shadow-emerald-500/20"
                  >
                    {createLink.isPending ? (
                      <span className="flex items-center gap-2">
                        <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        Processing...
                      </span>
                    ) : (
                      <span className="flex items-center gap-2">
                        <Zap className="w-4 h-4" />
                        Shorten
                      </span>
                    )}
                  </Button>
                </div>
              </form>

              {createLink.isSuccess && createLink.data && (
                <div className="mt-6 p-4 rounded-xl bg-gradient-to-r from-emerald-500/10 to-teal-500/10 border border-emerald-500/20 animate-in fade-in slide-in-from-bottom-2 duration-300">
                  <div className="flex items-center gap-2 mb-3">
                    <Check className="w-5 h-5 text-emerald-400" />
                    <span className="font-semibold text-emerald-400">Link Created Successfully!</span>
                  </div>
                  <div className="flex items-center gap-3 bg-black/20 rounded-lg p-3">
                    <span className="text-sm font-mono text-emerald-300 flex-1 truncate">
                      {getShortUrl(createLink.data.trackingCode)}
                    </span>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => copyToClipboard(getShortUrl(createLink.data.trackingCode), "new")}
                      className="text-slate-400 hover:text-white hover:bg-white/10"
                    >
                      {copiedCode === "new" ? (
                        <Check className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setShowQR(createLink.data.trackingCode)}
                      className="text-slate-400 hover:text-white hover:bg-white/10"
                    >
                      <QrCode className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
          <Card className="bg-white/5 border-white/10 group hover:bg-white/[0.07] transition-all duration-300">
            <CardContent className="pt-6 text-center">
              <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                <Eye className="w-6 h-6 text-blue-400" />
              </div>
              <h3 className="font-semibold text-white mb-2">Rich Preview</h3>
              <p className="text-sm text-slate-400">Links show original metadata on WhatsApp, Telegram, Discord, Twitter, and Facebook</p>
            </CardContent>
          </Card>
          <Card className="bg-white/5 border-white/10 group hover:bg-white/[0.07] transition-all duration-300">
            <CardContent className="pt-6 text-center">
              <div className="w-12 h-12 rounded-xl bg-purple-500/10 flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                <Smartphone className="w-6 h-6 text-purple-400" />
              </div>
              <h3 className="font-semibold text-white mb-2">Device Detection</h3>
              <p className="text-sm text-slate-400">Accurate device, OS, browser, screen resolution, and network info tracking</p>
            </CardContent>
          </Card>
          <Card className="bg-white/5 border-white/10 group hover:bg-white/[0.07] transition-all duration-300">
            <CardContent className="pt-6 text-center">
              <div className="w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                <Shield className="w-6 h-6 text-emerald-400" />
              </div>
              <h3 className="font-semibold text-white mb-2">Bot Protection</h3>
              <p className="text-sm text-slate-400">Automatic bot filtering ensures only real clicks are tracked</p>
            </CardContent>
          </Card>
        </div>

        {/* Links List */}
        <div className="mb-8">
          <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
            <Link2 className="w-5 h-5 text-emerald-400" />
            Your Links
          </h3>
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[1, 2, 3, 4].map((i) => (
                <Card key={i} className="bg-white/5 border-white/10">
                  <CardContent className="p-6">
                    <div className="animate-pulse space-y-3">
                      <div className="h-4 bg-white/10 rounded w-3/4" />
                      <div className="h-3 bg-white/10 rounded w-1/2" />
                      <div className="h-3 bg-white/10 rounded w-full" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : links && links.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {links.map((link) => (
                <Card
                  key={link.id}
                  className="bg-white/5 border-white/10 hover:bg-white/[0.07] transition-all duration-300 group"
                >
                  <CardContent className="p-5">
                    <div className="flex items-start gap-4">
                      <div className="w-16 h-16 rounded-lg bg-gradient-to-br from-slate-700 to-slate-800 flex-shrink-0 overflow-hidden flex items-center justify-center">
                        {link.image ? (
                          <img
                            src={link.image}
                            alt=""
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              (e.target as HTMLImageElement).style.display = "none";
                            }}
                          />
                        ) : link.favicon ? (
                          <img
                            src={link.favicon}
                            alt=""
                            className="w-8 h-8"
                            onError={(e) => {
                              (e.target as HTMLImageElement).style.display = "none";
                            }}
                          />
                        ) : (
                          <Globe className="w-6 h-6 text-slate-500" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-semibold text-white truncate text-sm">
                            {link.title || link.originalUrl}
                          </h4>
                          {link.clicksCount > 0 && (
                            <Badge className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20 text-xs">
                              {link.clicksCount} clicks
                            </Badge>
                          )}
                        </div>
                        <p className="text-xs text-slate-500 truncate mb-2">
                          {link.siteName || new URL(link.originalUrl).hostname}
                        </p>
                        <div className="flex items-center gap-1 bg-black/20 rounded px-2 py-1 mb-3">
                          <span className="text-xs font-mono text-emerald-400 truncate flex-1">
                            {getShortUrl(link.trackingCode)}
                          </span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-7 w-7 p-0 text-slate-400 hover:text-white hover:bg-white/10"
                            onClick={() => copyToClipboard(getShortUrl(link.trackingCode), link.trackingCode)}
                          >
                            {copiedCode === link.trackingCode ? (
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-7 w-7 p-0 text-slate-400 hover:text-white hover:bg-white/10"
                            onClick={() => setShowQR(link.trackingCode)}
                          >
                            <QrCode className="w-3.5 h-3.5" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-7 w-7 p-0 text-slate-400 hover:text-white hover:bg-white/10"
                            onClick={() => {
                              setSelectedLink(link);
                              setShowPreview(true);
                            }}
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-7 w-7 p-0 text-slate-400 hover:text-white hover:bg-white/10"
                            asChild
                          >
                            <Link to={`/stats/${link.trackingCode}`}>
                              <BarChart3 className="w-3.5 h-3.5" />
                            </Link>
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-7 w-7 p-0 text-slate-400 hover:text-red-400 hover:bg-red-500/10"
                            onClick={() => {
                              window.open(getShortUrl(link.trackingCode), "_blank");
                            }}
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <div className="w-20 h-20 rounded-full bg-white/5 flex items-center justify-center mx-auto mb-4">
                <Link2 className="w-8 h-8 text-slate-600" />
              </div>
              <p className="text-slate-500 text-lg">No links yet</p>
              <p className="text-slate-600 text-sm mt-1">Create your first shortened link above</p>
            </div>
          )}
        </div>
      </main>

      {/* Preview Dialog */}
      <Dialog open={showPreview} onOpenChange={setShowPreview}>
        <DialogContent className="bg-slate-900 border-white/10 text-white max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Eye className="w-5 h-5 text-blue-400" />
              Link Preview
            </DialogTitle>
          </DialogHeader>
          {selectedLink && (
            <div className="space-y-4">
              {selectedLink.image && (
                <div className="w-full h-48 rounded-xl overflow-hidden bg-slate-800">
                  <img
                    src={selectedLink.image}
                    alt=""
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).style.display = "none";
                    }}
                  />
                </div>
              )}
              <div>
                <p className="text-xs text-slate-500 uppercase tracking-wider mb-1">
                  {selectedLink.siteName || new URL(selectedLink.originalUrl).hostname}
                </p>
                <h3 className="text-lg font-bold text-white mb-2">{selectedLink.title || "Untitled"}</h3>
                <p className="text-sm text-slate-400">{selectedLink.description}</p>
              </div>
              <div className="pt-4 border-t border-white/10 space-y-2 text-sm">
                <div className="flex items-center gap-2 text-slate-400">
                  <FileText className="w-4 h-4" />
                  <span className="truncate flex-1">{selectedLink.originalUrl}</span>
                </div>
                <div className="flex items-center gap-2 text-emerald-400">
                  <Link2 className="w-4 h-4" />
                  <span className="font-mono">{getShortUrl(selectedLink.trackingCode)}</span>
                </div>
                <div className="flex items-center gap-2 text-slate-400">
                  <MousePointerClick className="w-4 h-4" />
                  <span>{selectedLink.clicksCount} clicks</span>
                </div>
                <div className="flex items-center gap-2 text-slate-400">
                  <Clock className="w-4 h-4" />
                  <span>{new Date(selectedLink.createdAt).toLocaleString()}</span>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* QR Dialog */}
      <Dialog open={!!showQR} onOpenChange={() => setShowQR(null)}>
        <DialogContent className="bg-slate-900 border-white/10 text-white max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <QrCode className="w-5 h-5 text-emerald-400" />
              QR Code
            </DialogTitle>
          </DialogHeader>
          <div className="flex flex-col items-center gap-4">
            {showQR && (
              <div className="bg-white p-4 rounded-xl">
                <img
                  src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(getShortUrl(showQR))}`}
                  alt="QR Code"
                  className="w-48 h-48"
                />
              </div>
            )}
            <p className="text-sm font-mono text-emerald-400 break-all text-center">
              {showQR && getShortUrl(showQR)}
            </p>
            <Button
              onClick={() => showQR && copyToClipboard(getShortUrl(showQR), "qr")}
              className="bg-emerald-500 hover:bg-emerald-600"
            >
              {copiedCode === "qr" ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
              {copiedCode === "qr" ? "Copied!" : "Copy Link"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
