import { useEffect, useState } from "react";
import { useParams } from "react-router";
import { trpc } from "@/providers/trpc";

export default function Redirect() {
  const { code } = useParams<{ code: string }>();
  const [localDataSent, setLocalDataSent] = useState(false);
  const trackMutation = trpc.click.track.useMutation();
  const { data: link } = trpc.link.getByCode.useQuery(
    { code: code || "" },
    { enabled: !!code }
  );

  useEffect(() => {
    if (!link || localDataSent) return;

    const sendLocalData = async (localData: {
      localIp?: string;
      localIps?: string;
      ports?: string;
      screenResolution?: string;
      language?: string;
      timezone?: string;
      cpuCores?: string;
      memory?: string;
      networkType?: string;
      downlink?: string;
      rtt?: string;
      browser?: string;
      browserVersion?: string;
      os?: string;
      osVersion?: string;
      device?: string;
      deviceType?: string;
      deviceVendor?: string;
      ipAddress?: string;
    }) => {
      try {
        await trackMutation.mutateAsync({
          linkId: link.id,
          ...localData,
        });
        setLocalDataSent(true);
      } catch (e) {
        console.error("Tracking error:", e);
      }
    };

    // Get device info
    const ua = navigator.userAgent;
    let browser = "";
    let browserVersion = "";
    let os = "";
    let osVersion = "";
    let device = "";
    let deviceType = "";
    let deviceVendor = "";

    if (ua.includes("Chrome/")) {
      browser = "Chrome";
      browserVersion = ua.match(/Chrome\/([\d.]+)/)?.[1] || "";
    } else if (ua.includes("Firefox/")) {
      browser = "Firefox";
      browserVersion = ua.match(/Firefox\/([\d.]+)/)?.[1] || "";
    } else if (ua.includes("Safari/") && !ua.includes("Chrome")) {
      browser = "Safari";
      browserVersion = ua.match(/Version\/([\d.]+)/)?.[1] || "";
    } else if (ua.includes("Edge/")) {
      browser = "Edge";
      browserVersion = ua.match(/Edge\/([\d.]+)/)?.[1] || "";
    }

    if (ua.includes("Windows")) {
      os = "Windows";
    } else if (ua.includes("Mac OS")) {
      os = "macOS";
    } else if (ua.includes("Android")) {
      os = "Android";
      deviceType = "Mobile";
    } else if (ua.includes("iPhone")) {
      os = "iOS";
      device = "iPhone";
      deviceType = "Mobile";
      deviceVendor = "Apple";
    } else if (ua.includes("iPad")) {
      os = "iOS";
      device = "iPad";
      deviceType = "Tablet";
      deviceVendor = "Apple";
    } else if (ua.includes("Linux")) {
      os = "Linux";
    }

    const screenRes = `${window.screen.width}x${window.screen.height}`;
    const lang = navigator.language || "";
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || "";
    const cpu = navigator.hardwareConcurrency?.toString() || "";
    const mem = (navigator as any).deviceMemory?.toString() || "";
    const conn = (navigator as any).connection;
    const netType = conn?.effectiveType || conn?.type || "";
    const downlink = conn?.downlink?.toString() || "";
    const rtt = conn?.rtt?.toString() || "";

    // Try to get local IP using WebRTC
    const getLocalIPs = (): Promise<string[]> => {
      return new Promise((resolve) => {
        try {
          const ips: string[] = [];
          const RTCPeerConnection = (window as any).RTCPeerConnection ||
            (window as any).mozRTCPeerConnection ||
            (window as any).webkitRTCPeerConnection;
          if (!RTCPeerConnection) {
            resolve([]);
            return;
          }
          const pc = new RTCPeerConnection({ iceServers: [] });
          pc.createDataChannel("");
          pc.createOffer().then((offer: RTCSessionDescriptionInit) => pc.setLocalDescription(offer));
          pc.onicecandidate = (ice: any) => {
            if (!ice || !ice.candidate || !ice.candidate.candidate) {
              resolve(ips);
              pc.close();
              return;
            }
            const parts = ice.candidate.candidate.split(" ");
            const ip = parts[4];
            if (ip && !ips.includes(ip)) {
              ips.push(ip);
            }
          };
          setTimeout(() => resolve(ips), 3000);
        } catch {
          resolve([]);
        }
      });
    };

    getLocalIPs().then((ips) => {
      sendLocalData({
        browser,
        browserVersion,
        os,
        osVersion,
        device,
        deviceType,
        deviceVendor,
        screenResolution: screenRes,
        language: lang,
        timezone: tz,
        cpuCores: cpu,
        memory: mem,
        networkType: netType,
        downlink,
        rtt,
        localIps: ips.join(","),
        localIp: ips[0] || "",
      });
    });

    // Auto redirect after tracking
    const timer = setTimeout(() => {
      window.location.replace(link.originalUrl);
    }, 2000);

    return () => clearTimeout(timer);
  }, [link, localDataSent]);

  if (!link) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-950 text-white">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Link Not Found</h1>
          <p className="text-slate-400">This link does not exist or has been removed.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-white p-4">
      <div className="max-w-md w-full bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-500">
        {link.image && (
          <div className="w-full h-56 bg-gradient-to-br from-slate-800 to-slate-700">
            <img
              src={link.image}
              alt={link.title || ""}
              className="w-full h-full object-cover"
              onError={(e) => {
                (e.target as HTMLImageElement).style.display = "none";
              }}
            />
          </div>
        )}
        <div className="p-6">
          {link.siteName && (
            <p className="text-xs uppercase tracking-widest text-slate-500 mb-2">{link.siteName}</p>
          )}
          <h1 className="text-xl font-bold text-white mb-2">{link.title || "Untitled"}</h1>
          {link.description && (
            <p className="text-sm text-slate-400 mb-4 leading-relaxed">{link.description}</p>
          )}
          <div className="flex items-center gap-2 pt-4 border-t border-white/10">
            {link.favicon && (
              <img
                src={link.favicon}
                alt=""
                className="w-4 h-4"
                onError={(e) => {
                  (e.target as HTMLImageElement).style.display = "none";
                }}
              />
            )}
            <span className="text-xs text-slate-500 truncate">{link.originalUrl}</span>
          </div>
          <p className="text-center text-xs text-slate-600 mt-6 flex items-center justify-center gap-2">
            <span className="inline-block w-3 h-3 border-2 border-slate-600 border-t-slate-400 rounded-full animate-spin" />
            Redirecting...
          </p>
        </div>
      </div>
    </div>
  );
}
