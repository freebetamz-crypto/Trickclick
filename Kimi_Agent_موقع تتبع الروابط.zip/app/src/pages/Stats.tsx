import { useParams, Link } from "react-router";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  BarChart3,
  ArrowLeft,
  Copy,
  Check,
  Globe,
  Smartphone,
  Monitor,
  Cpu,
  MapPin,
  Eye,
  Link2,
  MousePointerClick,
  Users,
  MonitorSmartphone,
  Maximize2,
  Layers,
  AlertCircle,
  Loader2,
} from "lucide-react";
import { useState } from "react";

export default function Stats() {
  const { code } = useParams<{ code: string }>();
  const [copied, setCopied] = useState(false);

  const { data, isLoading, error } = trpc.link.stats.useQuery(
    { code: code || "" },
    { enabled: !!code }
  );

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const getShortUrl = (code: string) => {
    return `${window.location.origin}/s/${code}`;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-white flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin text-emerald-400 mx-auto mb-4" />
          <p className="text-slate-400">Loading analytics...</p>
        </div>
      </div>
    );
  }

  if (error || !data || !data.link) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-white flex items-center justify-center">
        <div className="text-center max-w-md mx-auto p-6">
          <div className="w-16 h-16 rounded-full bg-red-500/10 flex items-center justify-center mx-auto mb-4">
            <AlertCircle className="w-8 h-8 text-red-400" />
          </div>
          <h2 className="text-xl font-bold mb-2">Link Not Found</h2>
          <p className="text-slate-400 mb-6">The tracking link you are looking for does not exist.</p>
          <Button asChild className="bg-emerald-500 hover:bg-emerald-600">
            <Link to="/">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Link>
          </Button>
        </div>
      </div>
    );
  }

  const { link, stats } = data;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-white">
      {/* Header */}
      <header className="border-b border-white/5 bg-white/[0.02] backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              asChild
              className="text-slate-400 hover:text-white hover:bg-white/10"
            >
              <Link to="/">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Link>
            </Button>
            <div className="h-6 w-px bg-white/10" />
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center">
                <BarChart3 className="w-4 h-4 text-white" />
              </div>
              <h1 className="font-bold">Link Analytics</h1>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Link Info */}
        <Card className="bg-white/5 border-white/10 mb-8">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="w-20 h-20 rounded-xl bg-gradient-to-br from-slate-700 to-slate-800 flex-shrink-0 overflow-hidden flex items-center justify-center">
                {link.image ? (
                  <img
                    src={link.image}
                    alt=""
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).style.display = "none";
                    }}
                  />
                ) : link.favicon ? (
                  <img
                    src={link.favicon}
                    alt=""
                    className="w-10 h-10"
                    onError={(e) => {
                      (e.target as HTMLImageElement).style.display = "none";
                    }}
                  />
                ) : (
                  <Globe className="w-8 h-8 text-slate-500" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <h2 className="text-lg font-bold text-white mb-1 truncate">{link.title || "Untitled"}</h2>
                <p className="text-sm text-slate-400 mb-3 line-clamp-2">{link.description}</p>
                <div className="flex flex-wrap items-center gap-3">
                  <div className="flex items-center gap-1 bg-black/20 rounded px-2 py-1">
                    <Link2 className="w-3 h-3 text-emerald-400" />
                    <span className="text-xs font-mono text-emerald-400">{getShortUrl(link.trackingCode)}</span>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-5 w-5 p-0 ml-1 text-slate-400 hover:text-white"
                      onClick={() => copyToClipboard(getShortUrl(link.trackingCode))}
                    >
                      {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    </Button>
                  </div>
                  <span className="text-xs text-slate-500">{link.siteName || new URL(link.originalUrl).hostname}</span>
                </div>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="border-white/10 text-slate-400 hover:text-white hover:bg-white/10"
                onClick={() => window.open(getShortUrl(link.trackingCode), "_blank")}
              >
                <Eye className="w-4 h-4 mr-2" />
                Visit
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Overview Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card className="bg-white/5 border-white/10">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
                <MousePointerClick className="w-5 h-5 text-blue-400" />
              </div>
              <div>
                <p className="text-2xl font-bold text-white">{stats.totalClicks}</p>
                <p className="text-xs text-slate-500">Total Clicks</p>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-white/5 border-white/10">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-purple-500/10 flex items-center justify-center">
                <Users className="w-5 h-5 text-purple-400" />
              </div>
              <div>
                <p className="text-2xl font-bold text-white">{stats.uniqueIPs}</p>
                <p className="text-xs text-slate-500">Unique IPs</p>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-white/5 border-white/10">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                <Smartphone className="w-5 h-5 text-emerald-400" />
              </div>
              <div>
                <p className="text-2xl font-bold text-white">
                  {Object.keys(stats.deviceTypes).length}
                </p>
                <p className="text-xs text-slate-500">Device Types</p>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-white/5 border-white/10">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-orange-500/10 flex items-center justify-center">
                <Monitor className="w-5 h-5 text-orange-400" />
              </div>
              <div>
                <p className="text-2xl font-bold text-white">
                  {Object.keys(stats.browsers).length}
                </p>
                <p className="text-xs text-slate-500">Browsers</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Detailed Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {/* Device Types */}
          <Card className="bg-white/5 border-white/10">
            <CardContent className="p-5">
              <h3 className="text-sm font-semibold text-slate-300 mb-4 flex items-center gap-2">
                <MonitorSmartphone className="w-4 h-4 text-emerald-400" />
                Device Types
              </h3>
              <div className="space-y-3">
                {Object.entries(stats.deviceTypes).length > 0 ? (
                  Object.entries(stats.deviceTypes)
                    .sort(([, a], [, b]) => (b as number) - (a as number))
                    .map(([device, count]) => (
                      <div key={device} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {device === "Mobile" ? (
                            <Smartphone className="w-3.5 h-3.5 text-slate-500" />
                          ) : device === "Tablet" ? (
                            <Monitor className="w-3.5 h-3.5 text-slate-500" />
                          ) : (
                            <Monitor className="w-3.5 h-3.5 text-slate-500" />
                          )}
                          <span className="text-sm text-slate-300">{device}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-20 h-1.5 bg-white/10 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-emerald-500 rounded-full"
                              style={{
                                width: `${(count as number) / (stats.totalClicks || 1) * 100}%`,
                              }}
                            />
                          </div>
                          <span className="text-xs text-slate-500 w-6 text-right">{count}</span>
                        </div>
                      </div>
                    ))
                ) : (
                  <p className="text-sm text-slate-600 text-center py-4">No data yet</p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Browsers */}
          <Card className="bg-white/5 border-white/10">
            <CardContent className="p-5">
              <h3 className="text-sm font-semibold text-slate-300 mb-4 flex items-center gap-2">
                <Globe className="w-4 h-4 text-blue-400" />
                Browsers
              </h3>
              <div className="space-y-3">
                {Object.entries(stats.browsers).length > 0 ? (
                  Object.entries(stats.browsers)
                    .sort(([, a], [, b]) => (b as number) - (a as number))
                    .map(([browser, count]) => (
                      <div key={browser} className="flex items-center justify-between">
                        <span className="text-sm text-slate-300">{browser}</span>
                        <div className="flex items-center gap-2">
                          <div className="w-20 h-1.5 bg-white/10 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-blue-500 rounded-full"
                              style={{
                                width: `${(count as number) / (stats.totalClicks || 1) * 100}%`,
                              }}
                            />
                          </div>
                          <span className="text-xs text-slate-500 w-6 text-right">{count}</span>
                        </div>
                      </div>
                    ))
                ) : (
                  <p className="text-sm text-slate-600 text-center py-4">No data yet</p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Operating Systems */}
          <Card className="bg-white/5 border-white/10">
            <CardContent className="p-5">
              <h3 className="text-sm font-semibold text-slate-300 mb-4 flex items-center gap-2">
                <Cpu className="w-4 h-4 text-purple-400" />
                Operating Systems
              </h3>
              <div className="space-y-3">
                {Object.entries(stats.os).length > 0 ? (
                  Object.entries(stats.os)
                    .sort(([, a], [, b]) => (b as number) - (a as number))
                    .map(([os, count]) => (
                      <div key={os} className="flex items-center justify-between">
                        <span className="text-sm text-slate-300">{os}</span>
                        <div className="flex items-center gap-2">
                          <div className="w-20 h-1.5 bg-white/10 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-purple-500 rounded-full"
                              style={{
                                width: `${(count as number) / (stats.totalClicks || 1) * 100}%`,
                              }}
                            />
                          </div>
                          <span className="text-xs text-slate-500 w-6 text-right">{count}</span>
                        </div>
                      </div>
                    ))
                ) : (
                  <p className="text-sm text-slate-600 text-center py-4">No data yet</p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Device Vendors */}
          <Card className="bg-white/5 border-white/10">
            <CardContent className="p-5">
              <h3 className="text-sm font-semibold text-slate-300 mb-4 flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-orange-400" />
                Device Vendors
              </h3>
              <div className="space-y-3">
                {Object.entries(stats.deviceVendors).length > 0 ? (
                  Object.entries(stats.deviceVendors)
                    .sort(([, a], [, b]) => (b as number) - (a as number))
                    .map(([vendor, count]) => (
                      <div key={vendor} className="flex items-center justify-between">
                        <span className="text-sm text-slate-300">{vendor}</span>
                        <div className="flex items-center gap-2">
                          <div className="w-20 h-1.5 bg-white/10 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-orange-500 rounded-full"
                              style={{
                                width: `${(count as number) / (stats.totalClicks || 1) * 100}%`,
                              }}
                            />
                          </div>
                          <span className="text-xs text-slate-500 w-6 text-right">{count}</span>
                        </div>
                      </div>
                    ))
                ) : (
                  <p className="text-sm text-slate-600 text-center py-4">No data yet</p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Screen Resolutions */}
          <Card className="bg-white/5 border-white/10">
            <CardContent className="p-5">
              <h3 className="text-sm font-semibold text-slate-300 mb-4 flex items-center gap-2">
                <Maximize2 className="w-4 h-4 text-pink-400" />
                Screen Resolutions
              </h3>
              <div className="space-y-3">
                {Object.entries(stats.screenResolutions).length > 0 ? (
                  Object.entries(stats.screenResolutions)
                    .sort(([, a], [, b]) => (b as number) - (a as number))
                    .map(([res, count]) => (
                      <div key={res} className="flex items-center justify-between">
                        <span className="text-sm text-slate-300 font-mono">{res}</span>
                        <div className="flex items-center gap-2">
                          <div className="w-20 h-1.5 bg-white/10 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-pink-500 rounded-full"
                              style={{
                                width: `${(count as number) / (stats.totalClicks || 1) * 100}%`,
                              }}
                            />
                          </div>
                          <span className="text-xs text-slate-500 w-6 text-right">{count}</span>
                        </div>
                      </div>
                    ))
                ) : (
                  <p className="text-sm text-slate-600 text-center py-4">No data yet</p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Countries */}
          <Card className="bg-white/5 border-white/10">
            <CardContent className="p-5">
              <h3 className="text-sm font-semibold text-slate-300 mb-4 flex items-center gap-2">
                <MapPin className="w-4 h-4 text-cyan-400" />
                Countries
              </h3>
              <div className="space-y-3">
                {Object.entries(stats.countries).length > 0 ? (
                  Object.entries(stats.countries)
                    .sort(([, a], [, b]) => (b as number) - (a as number))
                    .map(([country, count]) => (
                      <div key={country} className="flex items-center justify-between">
                        <span className="text-sm text-slate-300">{country}</span>
                        <div className="flex items-center gap-2">
                          <div className="w-20 h-1.5 bg-white/10 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-cyan-500 rounded-full"
                              style={{
                                width: `${(count as number) / (stats.totalClicks || 1) * 100}%`,
                              }}
                            />
                          </div>
                          <span className="text-xs text-slate-500 w-6 text-right">{count}</span>
                        </div>
                      </div>
                    ))
                ) : (
                  <p className="text-sm text-slate-600 text-center py-4">No data yet</p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Clicks Table */}
        <Card className="bg-white/5 border-white/10">
          <CardContent className="p-5">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <Layers className="w-5 h-5 text-emerald-400" />
              Recent Clicks
              <Badge className="ml-2 bg-white/10 text-slate-400">{stats.clicks.length} total</Badge>
            </h3>
            {stats.clicks.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-white/10 text-left text-slate-500">
                      <th className="pb-3 pr-4 font-medium">#</th>
                      <th className="pb-3 pr-4 font-medium">IP Address</th>
                      <th className="pb-3 pr-4 font-medium">Device</th>
                      <th className="pb-3 pr-4 font-medium">Browser</th>
                      <th className="pb-3 pr-4 font-medium">OS</th>
                      <th className="pb-3 pr-4 font-medium">Screen</th>
                      <th className="pb-3 pr-4 font-medium">Type</th>
                      <th className="pb-3 pr-4 font-medium">Time</th>
                    </tr>
                  </thead>
                  <tbody>
                    {stats.clicks.map((click, index) => (
                      <tr
                        key={click.id}
                        className="border-b border-white/5 hover:bg-white/[0.02] transition-colors"
                      >
                        <td className="py-3 pr-4 text-slate-500">{index + 1}</td>
                        <td className="py-3 pr-4">
                          <div className="flex flex-col">
                            <span className="font-mono text-xs text-emerald-400">{click.ipAddress || "-"}</span>
                            {click.localIp && (
                              <span className="font-mono text-xs text-blue-400">{click.localIp}</span>
                            )}
                          </div>
                        </td>
                        <td className="py-3 pr-4">
                          <div className="flex items-center gap-1">
                            <Smartphone className="w-3 h-3 text-slate-500" />
                            <span className="text-slate-300">{click.device || click.deviceVendor || "-"}</span>
                          </div>
                        </td>
                        <td className="py-3 pr-4 text-slate-300">{click.browser || "-"}</td>
                        <td className="py-3 pr-4 text-slate-300">{click.os || "-"}</td>
                        <td className="py-3 pr-4 font-mono text-xs text-slate-400">{click.screenResolution || "-"}</td>
                        <td className="py-3 pr-4">
                          <Badge className="bg-white/5 text-slate-400 text-xs">
                            {click.deviceType || "-"}
                          </Badge>
                        </td>
                        <td className="py-3 pr-4 text-slate-500 text-xs whitespace-nowrap">
                          {new Date(click.createdAt).toLocaleString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-12">
                <MousePointerClick className="w-10 h-10 text-slate-700 mx-auto mb-3" />
                <p className="text-slate-500">No clicks recorded yet</p>
                <p className="text-slate-600 text-sm mt-1">Share the link to start tracking</p>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
