import { Routes, Route } from 'react-router'
import Home from './pages/Home'
import Stats from './pages/Stats'
import Redirect from './pages/Redirect'

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/stats/:code" element={<Stats />} />
      <Route path="/s/:code" element={<Redirect />} />
    </Routes>
  )
}
