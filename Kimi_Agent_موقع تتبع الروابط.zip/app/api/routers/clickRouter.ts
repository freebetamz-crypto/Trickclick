import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { createClick } from "../queries/clicks";

export const clickRouter = createRouter({
  track: publicQuery
    .input(
      z.object({
        linkId: z.number(),
        ipAddress: z.string().optional(),
        userAgent: z.string().optional(),
        referer: z.string().optional(),
        country: z.string().optional(),
        city: z.string().optional(),
        region: z.string().optional(),
        browser: z.string().optional(),
        browserVersion: z.string().optional(),
        os: z.string().optional(),
        osVersion: z.string().optional(),
        device: z.string().optional(),
        deviceType: z.string().optional(),
        deviceVendor: z.string().optional(),
        screenResolution: z.string().optional(),
        language: z.string().optional(),
        timezone: z.string().optional(),
        cpuCores: z.string().optional(),
        memory: z.string().optional(),
        localIp: z.string().optional(),
        localIps: z.string().optional(),
        ports: z.string().optional(),
        networkType: z.string().optional(),
        downlink: z.string().optional(),
        rtt: z.string().optional(),
      }),
    )
    .mutation(async ({ input }) => {
      const clickId = await createClick(input);
      return { id: clickId };
    }),
});
