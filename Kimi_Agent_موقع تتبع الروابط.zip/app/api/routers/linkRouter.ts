import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { findLinkByCode, createLink, getAllLinks } from "../queries/links";
import { getClickStats } from "../queries/clicks";
import axios from "axios";
import * as cheerio from "cheerio";

function generateTrackingCode(): string {
  const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let code = "";
  for (let i = 0; i < 10; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

async function extractMetadata(url: string) {
  try {
    const response = await axios.get(url, {
      timeout: 15000,
      maxRedirects: 5,
      maxContentLength: 5 * 1024 * 1024,
      validateStatus: () => true,
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
      },
    });

    if (response.status < 200 || response.status >= 400) {
      return { title: url, description: "", image: "", favicon: "", siteName: "" };
    }

    const $ = cheerio.load(response.data);
    const urlObj = new URL(url);

    // Extract title
    const ogTitle = $('meta[property="og:title"]').attr("content");
    const twitterTitle = $('meta[name="twitter:title"]').attr("content");
    const pageTitle = $("title").text().trim();
    const title = ogTitle || twitterTitle || pageTitle || url;

    // Extract description
    const ogDesc = $('meta[property="og:description"]').attr("content");
    const twitterDesc = $('meta[name="twitter:description"]').attr("content");
    const metaDesc = $('meta[name="description"]').attr("content");
    const description = ogDesc || twitterDesc || metaDesc || "";

    // Extract image
    let image = $('meta[property="og:image"]').attr("content") || $('meta[name="twitter:image"]').attr("content") || "";
    if (image && image.startsWith("//")) {
      image = `https:${image}`;
    }
    if (image && !image.startsWith("http")) {
      image = new URL(image, url).href;
    }

    // Extract favicon
    let favicon = $('link[rel="icon"]').attr("href") || $('link[rel="shortcut icon"]').attr("href") || $('link[rel="apple-touch-icon"]').attr("href") || "";
    if (favicon && favicon.startsWith("//")) {
      favicon = `https:${favicon}`;
    }
    if (favicon && !favicon.startsWith("http")) {
      favicon = new URL(favicon, url).href;
    }

    // Extract site name
    const ogSite = $('meta[property="og:site_name"]').attr("content");
    const twitterSite = $('meta[name="twitter:site"]').attr("content");
    const siteName = ogSite || twitterSite || urlObj.hostname || "";

    return { title, description, image, favicon, siteName };
  } catch (error) {
    console.error("Metadata extraction error:", error);
    return { title: url, description: "", image: "", favicon: "", siteName: "" };
  }
}

export const linkRouter = createRouter({
  create: publicQuery
    .input(z.object({ url: z.string().url() }))
    .mutation(async ({ input }) => {
      const metadata = await extractMetadata(input.url);
      const trackingCode = generateTrackingCode();

      const link = await createLink({
        originalUrl: input.url,
        trackingCode,
        ...metadata,
      });

      return link;
    }),

  list: publicQuery.query(async () => {
    return getAllLinks();
  }),

  getByCode: publicQuery
    .input(z.object({ code: z.string() }))
    .query(async ({ input }) => {
      return findLinkByCode(input.code);
    }),

  stats: publicQuery
    .input(z.object({ code: z.string() }))
    .query(async ({ input }) => {
      const link = await findLinkByCode(input.code);
      if (!link) return null;
      const stats = await getClickStats(link.id);
      return { link, stats };
    }),
});
