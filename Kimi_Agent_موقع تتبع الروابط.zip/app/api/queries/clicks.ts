import { getDb } from "./connection";
import { clicks } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export async function createClick(data: {
  linkId: number;
  ipAddress?: string;
  userAgent?: string;
  referer?: string;
  country?: string;
  city?: string;
  region?: string;
  browser?: string;
  browserVersion?: string;
  os?: string;
  osVersion?: string;
  device?: string;
  deviceType?: string;
  deviceVendor?: string;
  screenResolution?: string;
  language?: string;
  timezone?: string;
  cpuCores?: string;
  memory?: string;
  localIp?: string;
  localIps?: string;
  ports?: string;
  networkType?: string;
  downlink?: string;
  rtt?: string;
}) {
  const db = getDb();
  const result = await db.insert(clicks).values(data).$returningId();
  return result[0].id;
}

export async function getClicksByLinkId(linkId: number) {
  const db = getDb();
  return db.select().from(clicks).where(eq(clicks.linkId, linkId)).orderBy(desc(clicks.createdAt));
}

export async function getClickStats(linkId: number) {
  const db = getDb();
  const linkClicks = await db.select().from(clicks).where(eq(clicks.linkId, linkId));
  
  // Browser stats
  const browserMap = new Map<string, number>();
  const osMap = new Map<string, number>();
  const deviceMap = new Map<string, number>();
  const deviceVendorMap = new Map<string, number>();
  const countryMap = new Map<string, number>();
  const deviceTypeMap = new Map<string, number>();
  const ips = new Set<string>();
  const screenResolutions = new Map<string, number>();
  
  for (const click of linkClicks) {
    if (click.browser) browserMap.set(click.browser, (browserMap.get(click.browser) || 0) + 1);
    if (click.os) osMap.set(click.os, (osMap.get(click.os) || 0) + 1);
    if (click.device) deviceMap.set(click.device, (deviceMap.get(click.device) || 0) + 1);
    if (click.deviceVendor) deviceVendorMap.set(click.deviceVendor, (deviceVendorMap.get(click.deviceVendor) || 0) + 1);
    if (click.country) countryMap.set(click.country, (countryMap.get(click.country) || 0) + 1);
    if (click.deviceType) deviceTypeMap.set(click.deviceType, (deviceTypeMap.get(click.deviceType) || 0) + 1);
    if (click.ipAddress) ips.add(click.ipAddress);
    if (click.screenResolution) screenResolutions.set(click.screenResolution, (screenResolutions.get(click.screenResolution) || 0) + 1);
  }
  
  return {
    totalClicks: linkClicks.length,
    uniqueIPs: ips.size,
    browsers: Object.fromEntries(browserMap),
    os: Object.fromEntries(osMap),
    devices: Object.fromEntries(deviceMap),
    deviceVendors: Object.fromEntries(deviceVendorMap),
    countries: Object.fromEntries(countryMap),
    deviceTypes: Object.fromEntries(deviceTypeMap),
    screenResolutions: Object.fromEntries(screenResolutions),
    clicks: linkClicks,
  };
}
