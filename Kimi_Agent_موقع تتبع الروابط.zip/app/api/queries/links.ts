import { getDb } from "./connection";
import { links } from "@db/schema";
import { eq } from "drizzle-orm";

export async function findLinkByCode(trackingCode: string) {
  const db = getDb();
  const result = await db.select().from(links).where(eq(links.trackingCode, trackingCode)).limit(1);
  return result[0] || null;
}

export async function findLinkById(id: number) {
  const db = getDb();
  const result = await db.select().from(links).where(eq(links.id, id)).limit(1);
  return result[0] || null;
}

export async function createLink(data: {
  originalUrl: string;
  trackingCode: string;
  title?: string;
  description?: string;
  image?: string;
  favicon?: string;
  siteName?: string;
}) {
  const db = getDb();
  const result = await db.insert(links).values(data).$returningId();
  return findLinkById(result[0].id);
}

export async function incrementClicks(id: number) {
  const db = getDb();
  const link = await findLinkById(id);
  if (!link) return null;
  await db.update(links).set({ clicksCount: link.clicksCount + 1 }).where(eq(links.id, id));
  return findLinkById(id);
}

export async function getAllLinks() {
  const db = getDb();
  return db.select().from(links).orderBy(links.createdAt);
}
