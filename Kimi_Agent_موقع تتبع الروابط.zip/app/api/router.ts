import { createRouter, publicQuery } from "./middleware";
import { linkRouter } from "./routers/linkRouter";
import { clickRouter } from "./routers/clickRouter";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  link: linkRouter,
  click: clickRouter,
});

export type AppRouter = typeof appRouter;
