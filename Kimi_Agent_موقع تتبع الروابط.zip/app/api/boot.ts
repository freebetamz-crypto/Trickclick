import { Hono } from "hono";
import { bodyLimit } from "hono/body-limit";
import type { HttpBindings } from "@hono/node-server";
import { fetchRequestHandler } from "@trpc/server/adapters/fetch";
import { appRouter } from "./router";
import { createContext } from "./context";
import { env } from "./lib/env";
import { getDb } from "./queries/connection";
import { links, clicks } from "@db/schema";
import { eq } from "drizzle-orm";

const app = new Hono<{ Bindings: HttpBindings }>();

// Bot user agents pattern
const BOT_PATTERN = /facebookexternalhit|Facebot|Twitterbot|Slackbot|Discordbot|WhatsApp|TelegramBot|LinkedInBot|SkypeUriPreview|Googlebot|bingbot|WhatsApp|Instagram/i;

// Serve tRPC API
app.use(bodyLimit({ maxSize: 50 * 1024 * 1024 }));
app.use("/api/trpc/*", async (c) => {
  return fetchRequestHandler({
    endpoint: "/api/trpc",
    req: c.req.raw,
    router: appRouter,
    createContext,
  });
});

// Redirect route for short links with preview
app.get("/s/:code", async (c) => {
  const code = c.req.param("code");
  const db = getDb();

  const result = await db
    .select()
    .from(links)
    .where(eq(links.trackingCode, code))
    .limit(1);

  if (!result.length) {
    return c.html(
      `<!DOCTYPE html>
      <html>
      <head><title>404 - Link Not Found</title></head>
      <body><h1>404 - Link Not Found</h1></body>
      </html>`,
      404
    );
  }

  const link = result[0];
  const userAgent = c.req.header("user-agent") || "";
  const isBot = BOT_PATTERN.test(userAgent);

  // Only track real users, not bots
  if (!isBot) {
    try {
      const headers = c.req.header();
      const forwarded = headers["x-forwarded-for"];
      const realIp = headers["x-real-ip"];
      const ipAddress = forwarded?.split(",")[0]?.trim() || realIp || "unknown";

      // Parse user agent for device info
      let browser = "";
      let browserVersion = "";
      let os = "";
      let osVersion = "";
      let device = "";
      let deviceType = "";
      let deviceVendor = "";

      // Parse browser
      if (userAgent.includes("Chrome/")) {
        browser = "Chrome";
        browserVersion = userAgent.match(/Chrome\/([\d.]+)/)?.[1] || "";
      } else if (userAgent.includes("Firefox/")) {
        browser = "Firefox";
        browserVersion = userAgent.match(/Firefox\/([\d.]+)/)?.[1] || "";
      } else if (userAgent.includes("Safari/") && !userAgent.includes("Chrome")) {
        browser = "Safari";
        browserVersion = userAgent.match(/Version\/([\d.]+)/)?.[1] || "";
      } else if (userAgent.includes("Edge/")) {
        browser = "Edge";
        browserVersion = userAgent.match(/Edge\/([\d.]+)/)?.[1] || "";
      } else if (userAgent.includes("Opera/") || userAgent.includes("OPR/")) {
        browser = "Opera";
        browserVersion = userAgent.match(/(?:Opera|OPR)\/([\d.]+)/)?.[1] || "";
      }

      // Parse OS
      if (userAgent.includes("Windows NT 10.0")) {
        os = "Windows";
        osVersion = "10";
      } else if (userAgent.includes("Windows NT 6.3")) {
        os = "Windows";
        osVersion = "8.1";
      } else if (userAgent.includes("Windows NT 6.2")) {
        os = "Windows";
        osVersion = "8";
      } else if (userAgent.includes("Windows NT 6.1")) {
        os = "Windows";
        osVersion = "7";
      } else if (userAgent.includes("Mac OS X")) {
        os = "macOS";
        osVersion = userAgent.match(/Mac OS X ([\d_]+)/)?.[1]?.replace(/_/g, ".") || "";
      } else if (userAgent.includes("Android")) {
        os = "Android";
        osVersion = userAgent.match(/Android ([\d.]+)/)?.[1] || "";
      } else if (userAgent.includes("iPhone") || userAgent.includes("iPad")) {
        os = "iOS";
        osVersion = userAgent.match(/OS ([\d_]+)/)?.[1]?.replace(/_/g, ".") || "";
      } else if (userAgent.includes("Linux")) {
        os = "Linux";
      }

      // Parse device type and name
      if (userAgent.includes("iPhone")) {
        device = "iPhone";
        deviceType = "Mobile";
        deviceVendor = "Apple";
      } else if (userAgent.includes("iPad")) {
        device = "iPad";
        deviceType = "Tablet";
        deviceVendor = "Apple";
      } else if (userAgent.includes("Samsung")) {
        deviceType = "Mobile";
        deviceVendor = "Samsung";
        const modelMatch = userAgent.match(/Samsung(?:GT-|SM-|SCH-)?([A-Za-z0-9-]+)/);
        device = modelMatch ? `Samsung ${modelMatch[1]}` : "Samsung Device";
      } else if (userAgent.includes("Pixel")) {
        deviceType = "Mobile";
        deviceVendor = "Google";
        const modelMatch = userAgent.match(/Pixel ([\d]+)/);
        device = modelMatch ? `Pixel ${modelMatch[1]}` : "Pixel";
      } else if (userAgent.includes("Xiaomi") || userAgent.includes("Mi ")) {
        deviceType = "Mobile";
        deviceVendor = "Xiaomi";
        device = "Xiaomi";
      } else if (userAgent.includes("Huawei")) {
        deviceType = "Mobile";
        deviceVendor = "Huawei";
        device = "Huawei";
      } else if (userAgent.includes("OnePlus")) {
        deviceType = "Mobile";
        deviceVendor = "OnePlus";
        device = "OnePlus";
      } else if (userAgent.includes("OPPO")) {
        deviceType = "Mobile";
        deviceVendor = "OPPO";
        device = "OPPO";
      } else if (userAgent.includes("vivo")) {
        deviceType = "Mobile";
        deviceVendor = "vivo";
        device = "vivo";
      } else if (userAgent.includes("Windows Phone")) {
        deviceType = "Mobile";
        deviceVendor = "Microsoft";
        device = "Windows Phone";
      } else if (userAgent.includes("BlackBerry")) {
        deviceType = "Mobile";
        deviceVendor = "BlackBerry";
        device = "BlackBerry";
      } else if (/Mobile|Android/.test(userAgent)) {
        deviceType = "Mobile";
      } else if (/Tablet|iPad/.test(userAgent)) {
        deviceType = "Tablet";
      } else {
        deviceType = "Desktop";
      }

      await db.insert(clicks).values({
        linkId: link.id,
        ipAddress,
        userAgent,
        referer: headers["referer"] || "",
        browser,
        browserVersion,
        os,
        osVersion,
        device,
        deviceType,
        deviceVendor,
        language: "",
        timezone: "",
      });

      // Increment click count
      await db
        .update(links)
        .set({ clicksCount: link.clicksCount + 1 })
        .where(eq(links.id, link.id));
    } catch (e) {
      console.error("Tracking error:", e);
    }
  }

  // Escape values for HTML
  const escapedTitle = (link.title || "Untitled").replace(/"/g, "&quot;");
  const escapedDescription = (link.description || "").replace(/"/g, "&quot;");
  const escapedImage = (link.image || "").replace(/"/g, "&quot;");
  const escapedUrl = link.originalUrl.replace(/"/g, "&quot;");
  const escapedSiteName = (link.siteName || "").replace(/"/g, "&quot;");
  const escapedFavicon = (link.favicon || "").replace(/"/g, "&quot;");

  return c.html(`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${escapedTitle}</title>
  <meta name="description" content="${escapedDescription}" />
  <meta name="robots" content="noindex,nofollow" />
  
  <!-- Open Graph / Facebook -->
  <meta property="og:type" content="website" />
  <meta property="og:title" content="${escapedTitle}" />
  <meta property="og:description" content="${escapedDescription}" />
  <meta property="og:image" content="${escapedImage}" />
  <meta property="og:url" content="${escapedUrl}" />
  <meta property="og:site_name" content="${escapedSiteName}" />
  
  <!-- Twitter -->
  <meta name="twitter:card" content="summary_large_image" />
  <meta name="twitter:title" content="${escapedTitle}" />
  <meta name="twitter:description" content="${escapedDescription}" />
  <meta name="twitter:image" content="${escapedImage}" />
  
  <!-- Telegram / WhatsApp -->
  <meta property="og:image:width" content="1200" />
  <meta property="og:image:height" content="630" />
  
  <!-- Redirect -->
  <meta http-equiv="refresh" content="0;url=${escapedUrl}" />
  <link rel="canonical" href="${escapedUrl}" />
  ${escapedFavicon ? `<link rel="icon" href="${escapedFavicon}" />` : ""}
  
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0f172a 100%);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }
    .preview-card {
      background: rgba(255,255,255,0.05);
      border: 1px solid rgba(255,255,255,0.1);
      border-radius: 20px;
      max-width: 500px;
      width: 100%;
      overflow: hidden;
      backdrop-filter: blur(10px);
      animation: fadeIn 0.5s ease-out;
    }
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }
    .preview-image {
      width: 100%;
      height: 260px;
      object-fit: cover;
      background: linear-gradient(135deg, #1e293b, #334155);
    }
    .preview-body {
      padding: 24px;
    }
    .site-name {
      font-size: 12px;
      color: #94a3b8;
      text-transform: uppercase;
      letter-spacing: 1px;
      margin-bottom: 8px;
    }
    .preview-title {
      font-size: 22px;
      font-weight: 700;
      color: #f1f5f9;
      margin-bottom: 10px;
      line-height: 1.3;
    }
    .preview-desc {
      font-size: 14px;
      color: #94a3b8;
      line-height: 1.6;
      margin-bottom: 16px;
    }
    .preview-url {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 12px;
      color: #64748b;
      padding-top: 16px;
      border-top: 1px solid rgba(255,255,255,0.08);
    }
    .preview-url img {
      width: 16px;
      height: 16px;
    }
    .redirect-msg {
      text-align: center;
      margin-top: 16px;
      font-size: 13px;
      color: #64748b;
    }
    .spinner {
      display: inline-block;
      width: 14px;
      height: 14px;
      border: 2px solid rgba(100, 116, 139, 0.3);
      border-top-color: #64748b;
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
      margin-right: 6px;
      vertical-align: middle;
    }
    @keyframes spin { to { transform: rotate(360deg); } }
  </style>
</head>
<body>
  <div class="preview-card">
    ${escapedImage ? `<img class="preview-image" src="${escapedImage}" alt="${escapedTitle}" onerror="this.style.display='none'" />` : ""}
    <div class="preview-body">
      ${escapedSiteName ? `<div class="site-name">${escapedSiteName}</div>` : ""}
      <div class="preview-title">${escapedTitle}</div>
      ${escapedDescription ? `<div class="preview-desc">${escapedDescription}</div>` : ""}
      <div class="preview-url">
        ${escapedFavicon ? `<img src="${escapedFavicon}" alt="" onerror="this.style.display='none'" />` : ""}
        <span>${new URL(link.originalUrl).hostname}</span>
      </div>
    </div>
  </div>
  <script>
    window.location.replace("${escapedUrl}");
  </script>
</body>
</html>`);
});

app.all("/api/*", (c) => c.json({ error: "Not Found" }, 404));

export default app;

if (env.isProduction) {
  const { serve } = await import("@hono/node-server");
  const { serveStaticFiles } = await import("./lib/vite");
  serveStaticFiles(app);

  const port = parseInt(process.env.PORT || "3000");
  serve({ fetch: app.fetch, port }, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}
